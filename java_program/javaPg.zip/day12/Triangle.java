import java.lang.Math;
import java.io.*;
class Triangle
{   
	
	 int perimeter;
	 int s;
	 Double area;
	 Triangle(int a,int b,int c)
	{
		
		perimeter=a+b+c;
		s=(a+b+c)/2;
	    area=Math.sqrt(s*(s-a)*(s-b)*(s-c));
		
	}

	void display()
	{
		 System.out.println(area);
		 System.out.println(perimeter);
	}
  public static void main(String[] args) 
	 {  
	   int a=3,b=4,c=5;
	   Triangle obj=new Triangle(a,b,c);
       obj.display();

	}
 }