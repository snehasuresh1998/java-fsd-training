import java.util.*;
class DuckNo
{
 public static void main(String[] args)
 {
 	int n;
	Scanner sc=new Scanner(System.in);
    System.out.println("Enter a Number :");
    n=sc.nextInt();
    int temp=n;
    while (n!=0)
    {
      int rev=n%10;
      if(rev==0)
      {
      	System.out.println("The Number "+temp+ "  is a Duck Number ");
      }
      n=n/10;
    }
    System.out.println("The Number "+temp+ "  is  nota Duck Number ");
 }

}