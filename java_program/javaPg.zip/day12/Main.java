import java.util.*;
public class Main 
{  
   public static int palin(int num) 
   {  
       int r,sum=0;
       int temp=num;    
       while(num>0)
       {    
       r=num%10;    
       sum=(sum*10)+r;    
       num=num/10;    
       }    
      if(temp==sum)
      {
           return 1;  
      }    
         return 0;  
  }  
  public static void main(String[] args) 
  {
  int count=0;

    for(int i=1;i<=1000;i++)
    {
      int res=palin(i); 
    if(res==1)
    {
      System.out.println("The string  "+i+"is palindrome ");
      count++;
     
    }
    if(count==10)
      break;
    }
   } 
  
} 
