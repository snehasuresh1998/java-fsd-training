import java.util.*;

class QuickSort
{
    
   public static int partition(int arr[], int low, int high)
    {
        int pivot = arr[high]; 
        int i = (low-1); 
        for (int j=low; j<high; j++)
        {
           
            if (arr[j] <= pivot)
            {
                i++;
  
                

                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
  
        
        int temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;
  
        return i+1;
    }
  
    public static void sort(int arr[], int low, int high)
    {
        if (low < high)
        {
        
            int pi = partition(arr, low, high);
  
           
            sort(arr, low, pi-1);
            sort(arr, pi+1, high);
        }
    }
public static void main(String[] args)
 {
    int size;
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter size of array");
    size=sc.nextInt();
    int[] arr=new int[size];
    System.out.println("Enter  array elements");
    for(int i=0;i<size;i++)
    {
    arr[i]=sc.nextInt();
    }
    //partition(arr[], 0, size);
    sort(arr,0,size-1);
    System.out.println("The Sorted array ");
    for(int i=0;i<size;i++)
    {

    
    System.out.print(arr[i]);
}
}
}
