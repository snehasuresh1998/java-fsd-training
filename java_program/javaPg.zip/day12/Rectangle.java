import java.lang.Math;
import java.io.*;
class Rectangle
{   
	 int  area;
	 Rectangle(int a,int b,int c,int d)
	{
		this.q=a;
		this.b=b;
		this.c=c;
		this.d=d;
		
	}
	void area()
	{   
		super(a,b,c,d);
		int a1,a2;
		a1=a*b;
		a2=c*d;
		 System.out.println(a1);
		 System.out.println(a2);
	}

	
  public static void main(String[] args) 
	 { 
	   int a=4,b=5,c=5,d=8;
	   Rectangle obj=new Rectangle(a,b,c,d);
       obj.area();

	}
 }