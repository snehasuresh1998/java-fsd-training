import java.util.*;
class StrongNo
{
 public static int  factorial(int n)  
 {  
  if (n == 0)  
    return 1;  
  else  
    return(n * factorial(n-1));  
 }
 public static void main(String[] args)
 {
 int num;
 Scanner sc=new Scanner(System.in);
 System.out.println("Enter a Number :");
 num=sc.nextInt();
 int temp=num, sum=0;
  while (num!=0)
    {
      int rev=num%10;
      int f=factorial(rev);
      sum=sum+f;
      num=num/10;
    }
 if(sum==temp)
 {
 	System.out.println("The  Number "+temp+" is a strong Number :");

 }
 else
 {
 	System.out.println("The  Number "+temp+" is not a strong Number :");

 }
}
}





   