import java.lang.Math;
import java.io.*;
class Area
{   
	 int a=3,b=4,c=5;
	 int perimeter;
	 int s;
	 Double area;
	 public static Area()
	{
		
		perimeter=a+b+c;
		s=(a+b+c)/2;
	    area=Math.sqrt(s*(s-a)*(s-b)*(s-c));
		
	}

	void display()
	{
		 System.out.println(area);
		  System.out.println(perimeter);
	}
  public static void main(String[] args) 
	 {
	   Area obj=new Area();
       obj.display();

	}
  }

