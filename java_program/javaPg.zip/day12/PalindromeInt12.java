import java.util.*;
class PalindromeInt12
{
 public static  int palindromeInt(int n)  
 {  
 	int temp=n,rev=0,sum=0;
 	while(n!=0)
 	{
 		rev=n%10;
 		sum =(sum*10)+rev;
 		n=n/10;

 	}
  if(temp ==rev)
  {
  	return 1;
  }
  else
  {
  	return 0;
  }
 }
  public static void main(String[] args) 
  {
  int count=0;
 for (int i=1;i<=10000 ;i++ )
  { 
  int num1=i;
  int res=palindromeInt(num1);
  if(res==1)
  {
  	 count=count+1;
  	 System.out.println("The string "+"'"+i+"'"+" is palindrome ");
  }
  
 }

}

}


