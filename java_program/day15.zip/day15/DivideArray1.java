import java. lang. Exceptions;
import java.util.*;
class DivideArray1
{    
public static void main(String[] args)
{
    int n;
    Scanner sc =new Scanner(System.in);
    System.out.println("Enter the size of the array :");
    n=sc.nextInt();
    int[] a= new int[n];
    int[] ar= new int[n];
    int[] ar1= new int[n];
    
    System.out.println("Enter the array elements :");
    for( i=0;i<n;i++)
    {
     a[i]=sc.nextInt();
    }

System.out.println(" the array elements  are :");
 for(i=0;i<n;i++)
    {
     a[i];
    }


  }
}

