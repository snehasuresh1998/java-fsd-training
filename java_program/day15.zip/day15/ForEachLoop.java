

import java.util.*;
class ForEachLoop
 {
  public static void main(String[] args)
   {
     int[] arr=new int[10]; 
     Scanner sc =new Scanner(System.in);
     
    for(int i=0;i<10;i++)
    {
     arr[i]=sc.nextInt();
    }
   System.out.println("  ");
    for (int number: arr)
     {
      System.out.println(number);
    }
  }
}