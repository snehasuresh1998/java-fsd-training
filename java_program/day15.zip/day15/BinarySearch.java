import java.util.*;
class BinarySearch
 {  
    static int binarySearch(int a[], int beg, int end, int val)    
    {    
        int mid;    
        if(end >= beg)     
        {  
            mid = (beg + end)/2;    
            if(a[mid] == val)    
            {    
                return mid+1;  
            }    
             
            else if(a[mid] < val)     
            {  
                return binarySearch(a, mid+1, end, val);    
            }    
             
            else    
            {  
                return binarySearch(a, beg, mid-1, val);    
            }    
        }    
        return -1;    
    }   
    public static void main(String args[]) 
    {   
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size :");
        int n=sc.nextInt();
        int a[] = new int[n];
        System.out.println("Enter the array elements :");
        for (int i = 0; i < n; i++)  
        {  
            a[i] =sc.nextInt(); 
        }
        System.out.println("Enter the elements to be searched  :"); 
        int val = sc.nextInt();  
        int res = binarySearch(a, 0, n-1, val);  
        System.out.println("The elements of the array are: ");  
        for (int i = 0; i < n; i++)  
        {  
            System.out.print(a[i] + " ");  
        }  
        System.out.println();  
        System.out.println("Element to be searched is: " + val);  
        if (res == -1)  
        System.out.println("Element is not present in the array");  
        else  
        System.out.println("Element is present at " + res + " position of array");  
    }  
    }  