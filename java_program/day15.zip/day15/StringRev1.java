import java.util.*;
class StringRev1
{
 public static void main(String[] args)
 {
 	String str;
	Scanner sc=new Scanner(System.in);
    System.out.println("Enter a Sting :");
    str=sc.next();
    String str1=str.toLowerCase();
    int l=str1.length();
    for(int i =l-1; i>=0; i--)
    {
    	System.out.print(str.charAt(i)); 
  }
  //System.out.println(str1);
 }
}