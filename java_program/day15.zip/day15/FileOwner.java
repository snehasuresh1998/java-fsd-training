import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.*;
  
class FileOwner {
    public static void main(String[] args) {
  
        
        Path path = Paths.get("demo.txt");
  
        
        FileOwnerAttributeView file = Files.getFileAttributeView(path, 
                                        FileOwnerAttributeView.class);
  
        try {
            
            UserPrincipal user = file.getOwner();
  
            
            System.out.println("Owner: " + user.getName());
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}


