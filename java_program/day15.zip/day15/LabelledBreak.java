public class LabelledBreak
{
public static void main(String[] args)
{

int i=2;

loop1:
while(i<20)
{	
	if(i==10)
		break loop1;

	System.out.println("i ="+i); 
	i++;
}

System.out.println("Out of the loop");

} 

}