class Vehicle 
{
  protected String brand = "Ford";        
  public void honk() {                
    System.out.println("Ford");
  }
}

class Car extends Vehicle 
{
  private String modelName = "Mustang";
  public void display() {                
    System.out.println("Mustang");
  }
}
class Bike extends Vehicle
{
  private String modelName = "Ktm";
  public void display1() 
  {                
    System.out.println("KTm");
  }

  public static void main(String[] args)
   {
   Car c = new Car();
   Bike  b = new Bike();
    c.honk();
    b.display1();
    c.display();
  }
}