
import java.io.*;
import java.util.PriorityQueue;
class PriorityQueueExample
 {
  
    public static void main(String args[])
    {
        PriorityQueue<String> q = new PriorityQueue<>();
  
        q.add("anu");
        q.add("vinu");
        q.add("sanu");
        System.out.println(q);
        System.out.println(q.size());
        System.out.println(q.remove());


   }
}
