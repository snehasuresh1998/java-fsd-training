import java.io.*;
import java.util.ArrayList;
 
class ArrayListSpecific
{
 
    
    public static void main(String[] args)
    {
       
        ArrayList<String> list = new ArrayList<>();
 
        
        list.add("Anu");
        list.add("Binu");
        list.add("Cinu");
        System.out.println(list);
       
 
        
        list.add(1, "Dinu");
        list.add(2, "Elise");
 
        
        System.out.println(list);
    }
}
 
 

