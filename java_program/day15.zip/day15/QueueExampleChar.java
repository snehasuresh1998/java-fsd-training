import java.util.LinkedList;
import java.util.Queue;
class QueueExampleChar
{
 public static void main(String[] args) 
 {
 	Queue<Character> q = new LinkedList<>();
 	Queue<Character> q1= new LinkedList<>();
        q.add('a');
        q.add('c');
        q1.add('h');
        q1.add('u');
        q1.add('z');
        System.out.println(q);
        System.out.println(q1);
        q.addAll(q1);
        System.out.println("Queue after addAll method ");
        System.out.println(q);
        int size = q.size();
        System.out.println("Size of queue-"+ size);
        char  rem = q.remove();
        System.out.println("removed element-"+ rem);
        System.out.println(q);
        System.out.println("Did the queue is empty :"+q.isEmpty());
        System.out.println("The element '3' is present : "+q.contains(3));
        q.clear();
        System.out.println(q);


 }
}