import java.io.*;
import java.util.*;
  
class AddElementsToHashtable2 {
    public static void main(String args[])
    {
        // No need to mention the
        // Generic type twice
        Hashtable<Integer, Double> ht1 = new Hashtable<>(4);
  
        // Initialization of a Hashtable
        // using Generics
        Hashtable<Integer, Double> ht2
            = new Hashtable<Integer, Double>(2);
  
        // Inserting the Elements
        // using put() method
        ht1.put(1, 1.2);
        ht1.put(2, 2.90);
        ht1.put(3, 567.890);
  
        ht2.put(4, 2.111);
        ht2.put(5, 4.67);
        ht2.put(6, 1.2);
  
        // Print mappings to the console
        System.out.println("Mappings of ht1 : " + ht1);
        System.out.println("Mappings of ht2 : " + ht2);
    }
}
