class Student 
{
   private int rno;
   private String name;
   public Student(int r, String n)
    {
      rno = r;
      name = n;
   }
   public void display() {
      System.out.println("Roll Number: " + rno);
      System.out.println("Name: " + name);
   }
}
public class DemoConstructor
{
   public static void main(String[] args) {
      Student s = new Student(173, "Susan");
      Student s1 = new Student(111, "John");

      s.display();
      s1.display();
   }
}