
import java.io.*;
import java.util.PriorityQueue;
public class PriorityQueue
 {
  
    public static void main(String args[])
    {
        PriorityQueue<String> q = new PriorityQueue<>();
  
        q.add("anu");
        q.add("vinu");
        q.add("sanu");
        System.out.println(q);
        System.out.println(q.remove());


   }
}
