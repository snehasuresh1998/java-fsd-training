class Sum
{  
static int add(int a,int b){
return a+b;
}  
static int add(int a,int b,int c)
{
return a+b+c;
}  
}  
class TestOverloading
{  
public static void main(String[] args)
{  
System.out.println(Sum.add(10,11));  
System.out.println(Sum.add(12,51,111));  
}
}  