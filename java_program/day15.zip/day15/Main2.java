import java.util.*;
import java.lang.Math;

class Main2 {
  public static void main(String[] args) 
  { 
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter  the range");
    //int n=sc.nextInt();
    int array[] = new int[100];
    for(int i=0;i<100;i++)
    {
     array[i] =i+1;
    }
    int lcm = array[0];
    int gcd = array[0];
 
    for(int i=1; i<array.length; i++)
    { 
      
      
      gcd = findGCD(array[i], lcm);
      lcm = (lcm*array[i])/gcd;
      
      
    }
    
   System.out.println(" Perfectly divisible  by "+Math.abs(lcm));
    
  }
 
  public static int findGCD(int a, int b)
  {
  
    if(b == 0)
      return a;
    
    return findGCD(b, a%b);
  }
}