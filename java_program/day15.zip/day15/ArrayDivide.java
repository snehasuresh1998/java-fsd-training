import java.util.*;

class ArrayDivide
{   
     public static int min(int[] arr)
      {  
  
         
        int min = arr[0];  
       
        for (int i = 0; i < arr.length; i++) {  
            
           if(arr[i] <min)  
               min = arr[i];  
        }  
        return min;
    }  
 
public static  void main (String[] args)
     {  
        int count=0;
        System.out.println("Enter the size of the array:");
        Scanner sc= new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr=new int[n];
        int[] arr1=new int[n];
        System.out.println("Enter the array elements:");
        for(int i=0;i<n;i++)
        {
         arr[i]=sc.nextInt();
        }
        int min= min(arr);
        try
        {
        for(int i=0;i<n;i++)
        {
         arr1[i]=arr[i]/min;
        }
        for(int i=0;i<n;i++)
        {
         System.out.print(" "+arr1[i]+" ");
        }
        
       }catch(Exception e){
        System.out.println(e);
       }
     finally
     {
        System.out.println("End of the program");
     }

}
}


