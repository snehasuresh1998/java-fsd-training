import java.io.*;
import java.util.*;
  
class AddElementsToHashtable5 {
    public static void main(String args[])
    {
        // No need to mention the
        // Generic type twice
        Hashtable<String, String> ht1
            = new Hashtable<>(4, 0.75f);
  
        // Initialization of a Hashtable
        // using Generics
        Hashtable<String, String> ht2
            = new Hashtable<String, String>(3, 0.5f);
  
        // Inserting the Elements
        // using put() method
        ht1.put("one","anu");
        ht1.put("two","vinu");
        ht1.put("three","sinu");
  
        ht2.put("four","sneha");
        ht2.put("five","gadha");
        ht2.put("six","vandhu");
  
        // Print mappings to the console
        System.out.println("Mappings of ht1 : " + ht1);
        System.out.println("Mappings of ht2 : " + ht2);
    }
}

