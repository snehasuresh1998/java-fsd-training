import java.util.LinkedList;
import java.util.Queue;
class QueueExample
{
 public static void main(String[] args) 
 {
 	Queue<Integer> q = new LinkedList<>();
 	Queue<Integer> q1= new LinkedList<>();
    for (int i = 0; i < 6; i++)
        {
            q.add(i);
        }
        q1.add(2);
        q1.add(23);
        q1.add(67);
        System.out.println(q);
        System.out.println("Size of queue-"+q.size());
        q.addAll(q1);
        System.out.println(q);
        int size = q.size();
        System.out.println("Size of queue-"+ size);
        System.out.println("Elements of queue "+ q);
        int rem = q.remove();
        System.out.println("removed element-"+ rem);
        System.out.println(q);
        System.out.println(" Did the queue is empty :"+q.isEmpty());
        System.out.println("The element '3' is present : "+q.contains(3));
        q.clear();
        System.out.println(q);


 }
}