import java.io.*;
import java.io.File;
import java.io.FileReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOper
 {
    public static void main(String[] args) 
    {
        String[] list = {"one", "two", "three", "four"};
        try {
            File file = new File("file.txt");
            FileWriter fileReader = new FileWriter(file);
            BufferedWriter bufferedWriter = new BufferedWriter(fileReader); 
            for (String s : list) {
                bufferedWriter.write(s + "\n");
            }

            bufferedWriter.close (); 
        } catch (Exception e) {
           System.out.println(e);
        }
        try 
        {
            File file = new File("file.txt");
            FileReader fileReader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while((line = bufferedReader.readLine()) != null)
             {
                System.out.println(line);
            }
            bufferedReader.close();
        }catch (Exception e)
         {
            System.out.println(e);
        }
        FileInputStream infile =null;
        try
        {
        infile=new FileInputStream("file.txt");
        int b;
        while((b=infile.read())!=-1)
        {
          System.out.println((char)b);
        }
         infile.close();
    }
    catch(IOException e)
        {
          System.out.println(e);
        }
        FileOutputStream ofile=null;
        byte b1[]={'a','p'};
        try{
           ofile=new FileOutputStream("file.txt");
        ofile.write(b1);
        ofile.close();
        }catch(IOException e)
        {
           System.out.println(e); 
        }
        
        
     
     }
}


 
   

  

    
