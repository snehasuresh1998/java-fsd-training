import java.io.*;
import java.util.*;
import java.util.Stack;  
class StackNextFor
{
public static void main(String[] args)   
{  

Stack<Integer> stk= new Stack<Integer>();  
Scanner sc=new Scanner(System.in);
System.out.println("Enter the Number of elements you want to enter into stack");
int n=sc.nextInt();
System.out.println("Enter elements ");  
for(int i=0;i<n;i++)
{ 
	int e=sc.nextInt();
    stk.push(e);  
}
System.out.println("Elements in Stack: " + stk);  
for(int i=0;i<n;i++)
{
  int res=stk.get(i);
  if(res==stk.peek())
  {
  	System.out.println(-1);
  	break;
  }
  System.out.println(res+1);

}
}
}