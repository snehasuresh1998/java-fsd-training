import java.util.LinkedList;
import java.util.Queue;
class QueueExampleString
{
 public static void main(String[] args) 
 {
 	Queue<String> q = new LinkedList<>();
 	Queue<String> q1= new LinkedList<>();
        q.add("ammu");
        q.add("annu");
        q1.add("ajay");
        q1.add("akhil");
        q1.add("achu");
        System.out.println(q);
        System.out.println(q1);
        q.addAll(q1);
        System.out.println("Queue after addAll method ");
        System.out.println(q);
        int size = q.size();
        System.out.println("Size of queue-"+ size);
        String  rem = q.remove();
        System.out.println("removed element-"+ rem);
        System.out.println(q);
        System.out.println("Did the queue is empty :"+q.isEmpty());
        System.out.println("The element '3' is present : "+q.contains(3));
        q.clear();
        System.out.println(q);


 }
}