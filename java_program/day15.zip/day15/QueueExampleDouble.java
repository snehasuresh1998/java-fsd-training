import java.util.LinkedList;
import java.util.Queue;
class QueueExampleDouble
{
 public static void main(String[] args) 
 {
 	Queue<Double> q = new LinkedList<>();
 	Queue<Double> q1= new LinkedList<>();
        q.add(1.5);
        q.add(23.4);
        q1.add(2.00);
        q1.add(23.34);
        q1.add(67.6);
        System.out.println(q);
        System.out.println(q1);
        q.addAll(q1);
        System.out.println("Queue after addAll method ");
        System.out.println(q);
        int size = q.size();
        System.out.println("Size of queue-"+ size);
        Double rem = q.remove();
        System.out.println("removed element-"+ rem);
        System.out.println(q);
        System.out.println(" Did the queue is empty :"+q.isEmpty());
        System.out.println("The element '3' is present : "+q.contains(3));
        q.clear();
        System.out.println(q);


 }
}