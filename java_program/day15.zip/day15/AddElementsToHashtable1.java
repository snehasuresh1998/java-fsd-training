import java.io.*;
import java.util.*;
  
class AddElementsToHashtable1
 {
    public static void main(String args[])
    {
        
        Hashtable<Character, Integer> ht1 = new Hashtable<>();
  
        
        Hashtable<Character, Integer> ht2= new Hashtable<Character, Integer>();
  
        // Inserting the Elements
        // using put() method
        ht1.put('a', 1);
        ht1.put('b', 2);
        ht1.put('c', 3);
  
        ht2.put('d', 4);
        ht2.put('e', 5);
        ht2.put('f', 6);
  
        // Print mappings to the console
        System.out.println("Mappings of ht1 : " + ht1);
        System.out.println("Mappings of ht2 : " + ht2);
    }
}