class Ex
{
	int sum=0;  
	void disp()
	{
		System.out.println("show");
	} 
  void add(int a,int b)
  {
  	sum=a+b;
  	System.out.println(sum);
  }
  void add(int a,int b,int c)
  {
   sum=a+b+c;
   System.out.println(sum);
   }   
}  
class Example extends Ex
{
    void disp()
      {
         System.out.println("showing ");
      } 
	public static void main(String[] args) 
	{
    Ex e1=new Example();
 e1.disp();
 e1.add(10,10);
 e1.add(10,10,10);
 }  

}   