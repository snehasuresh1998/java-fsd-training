import java.io.*;
import java.util.*;
import java.util.Stack;  
class Stack4
{
public static void main(String[] args)   
{  

Stack<String> stk= new Stack<String>();  

boolean result = stk.empty();  
System.out.println("Is the stack empty? " + result);
stk.push("anu");  
stk.push("vinu");  
stk.push("sanu");  
stk.push("manu");  
System.out.println("Elements in Stack: " + stk);  
result = stk.empty();  
System.out.println("Is the stack empty? " + result); 
stk.pop(); 
System.out.println("Elements in Stack: " + stk);
System.out.println("Does the stack contains sanu :" + stk.search("sanu"));
System.out.println( stk.peek());



}
}