import java.io.*;
import java.util.*;
import java.util.Stack;  
class Stack2
{
public static void main(String[] args)   
{  

Stack<Double> stk= new Stack<Double>();  

boolean result = stk.empty();  
System.out.println("Is the stack empty? " + result);
stk.push(110.9);  
stk.push(113.89);  
stk.push(90.56);  
stk.push(120.0);  
System.out.println("Elements in Stack: " + stk);  
result = stk.empty();  
System.out.println("Is the stack empty? " + result); 
stk.pop(); 
System.out.println("Elements in Stack: " + stk);
System.out.println("Does the stack contains 110.9 :" + stk.search(110.9));
System.out.println( stk.peek());

}
}