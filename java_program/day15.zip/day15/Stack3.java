import java.io.*;
import java.util.*;
import java.util.Stack;  
class Stack3
{
public static void main(String[] args)   
{  

Stack<Character> stk= new Stack<Character>();  

boolean result = stk.empty();  
System.out.println("Is the stack empty? " + result);
stk.push('a');  
stk.push('b');  
stk.push('c');  
stk.push('d');  
System.out.println("Elements in Stack: " + stk);  
result = stk.empty();  
System.out.println("Is the stack empty? " + result);
stk.pop(); 
System.out.println("Elements in Stack: " + stk);
System.out.println("Does the stack contains c :" + stk.search('c'));
System.out.println( stk.peek());

}
}