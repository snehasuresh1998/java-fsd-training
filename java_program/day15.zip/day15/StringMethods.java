
import java.lang.String;
 
public class StringMethods {
 
    public static void main(String[] args) {
         
        String str = "softwareTesting";
        String str1 = "testing";
        String str2 = "blog";
        System.out.println(str.length());
        String replace = str.replace('o', 'u');
        System.out.println(str);
        System.out.println("testing is a part of Softwaretestinghelp: " + str.contains(str1));
        System.out.println("blog is a part of Softwaretestinghelp: " + str.contains(str2));
        System.out.println(str1.concat(str2));
        System.out.println(str1.equals(str2));
    }
 
}