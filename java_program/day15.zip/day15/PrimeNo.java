

import java.util.Scanner;
public class PrimeNo
{
	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter Ending Number : ");
		int end = sc.nextInt();
		System.out.println("Prime numbers between up to " +end );
		int count;
		for(int i = 1; i <= end ; i++)
		{
			count = 0;
			if (i == 1) 
             {
              System.out.println(i);
             } 
			for(int j = 1 ; j <= i ; j++)	
			{   
				if(i % j == 0)
					count = count+1;
			}
			if(count == 2)
				System.out.println(i);
		}
	
	}
}