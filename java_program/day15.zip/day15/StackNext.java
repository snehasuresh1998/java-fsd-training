import java.io.*;
import java.util.*;
import java.util.Stack;  
class StackNext
{
public static void main(String[] args)   
{  

Stack<Integer> stk= new Stack<Integer>();  

boolean result = stk.empty();  
System.out.println("Is the stack empty? " + result);
stk.push(1);  
stk.push(2);  
stk.push(3);  
stk.push(4);
stk.push(5); 
System.out.println("Elements in Stack: " + stk);  
for(int i=0;i<5;i++)
{
  int res=stk.get(i);
  if(res==5)
  {
  	System.out.println(-1);
  	break;
  }
  System.out.println(res+1);

}
}
}