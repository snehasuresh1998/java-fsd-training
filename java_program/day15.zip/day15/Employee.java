
import java.util.Arrays;
class Employee
{
 
   
    public static String[] removeTheElement(String[] arr, int index)
    {
 
        
        
        if (arr == null || index < 0
            || index >= arr.length) 
            {
 
            return arr;
        }
 
        
        String[] anotherArray = new String[arr.length - 1];
 

       
        for (int i = 0, k = 0; i < arr.length; i++) {
 
            
            if (i == index) {
                continue;
            }
 
            anotherArray[k++] = arr[i];
        }
 
        
        return anotherArray;
    }
 
    public static void main(String[] args)
    {
 
        
        String[] arr = { "anu","vinu","sanu","chinnu"};
 
       
        System.out.println("Original Array: "
                           + Arrays.toString(arr));
 
        int index = 1;
        int pos=index+1;
 
        System.out.println("Element  to be removed from: " + pos);
        arr = removeTheElement(arr, index);
        System.out.println("Resultant Array: "
                           + Arrays.toString(arr));
    }
}
 