import java.io.*;
 
class MethodEx 
{
   int s=0;
    void add(int a, int b)
    { 
     s=a+b;
      System.out.println(s);
    }
 
     void add(int a, int b, int c)
    {  
        s=a+b+c;
       System.out.println(s);
    }
     void disp()
    {
         System.out.println("i am main");
    }
    
}
class Ex extends MethodEx 
{
 public static void main(String[] args)
 {
    public  void disp()
    {
         System.out.println("overriding");
    }
    MethodEx o=new Ex();
    o.disp();
    o.add(1,2);
    o.add(2,3,4);
}
}