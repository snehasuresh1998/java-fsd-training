import java.io.*;
import java.util.*;
import java.util.Stack;  
class Stack1
{
public static void main(String[] args)   
{  

Stack<Integer> stk= new Stack<Integer>();  

boolean result = stk.empty();  
System.out.println("Is the stack empty? " + result);
stk.push(78);  
stk.push(113);  
stk.push(90);  
stk.push(120);  
System.out.println("Elements in Stack: " + stk);  
result = stk.empty();  
System.out.println("Is the stack empty? " + result);  
stk.pop(); 
System.out.println("Elements in Stack: " + stk);
System.out.println("Does the stack contains 113 :" + stk.search(113));
System.out.println( stk.peek());

}
}