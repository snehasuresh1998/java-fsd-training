class Cars
{
   public void disp()
   {
	System.out.println("Car");
   }
}

class Audi extends Cars
{
   public void disp()
   {
	System.out.println("Audi");
   }
}

class Benz extends Cars
{
   public void disp()
   {
	System.out.println("Benz");
   }
	
}

class Dacia extends Audi
{
   public void disp()
   {
	System.out.println("Dacia");
   }
   public static void main(String args[]){

	Dacia obj = new Dacia();
	obj.disp();
   }
}