import java.util.*;

class Main {
  public static void main(String[] args) 
  { 
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter  the range");
    int n=sc.nextInt();
    int array[] = new int[n];
    for(int i=0;i<n;i++)
    {
     array[i] =sc.nextInt();
    }
    int lcm = array[0];
    int gcd = array[0];
 
    for(int i=1; i<array.length; i++)
    {
      gcd = findGCD(array[i], lcm);
      lcm = (lcm*array[i])/gcd;
    }
    
    //output the LCM
    System.out.println(" Perfectly divisible  by "+lcm);
  }
 
  public static int findGCD(int a, int b){
  
    if(b == 0)
      return a;
    
    return findGCD(b, a%b);
  }
}