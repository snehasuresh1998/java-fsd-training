package com.example.springbootmongocrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMongoCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMongoCrudApplication.class, args);
	}

}
