package com.example.springbootmongocrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMongoCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
