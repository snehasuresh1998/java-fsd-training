import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
 
public class FileReaderExample1
{
    public static void main(String[] args) throws IOException
    {
        String fName = "demo.txt";
         
        BufferedReader br = new BufferedReader(new FileReader(fName));
         
        try {
            String line;
            while ((line = br.readLine()) != null) 
            {
               System.out.println(line);    
            }
        }
         finally
          {
            br.close();
        }
    }
}