import java.io.FileReader;
import java.io.IOException; 
import java.io.*;
 class ReadFile1 
 {
 public static void main(String[] args)
  {
 String name = "demo.txt";
 int ch;
 FileReader f1 =null;
 try
 {
 	f1 = new FileReader(name);
 	System.out.println("Ready to Read :");
 	
 }catch(IOException e)
 {
 	System.out.println(e);
 
  while ((ch=f1.read())!=-1)
   {

        System.out.print((char)ch);
        
    }
}

}


