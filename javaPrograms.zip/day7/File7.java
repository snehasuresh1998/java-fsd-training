import java.io.FileWriter;
import java.io.IOException;
class File7
{
    public static void main(String[] args) throws IOException
    {
    
        
       
        FileWriter fw=new FileWriter("output.txt");
        
        fw.flush();
        
         
        fw.close();
    }
}
