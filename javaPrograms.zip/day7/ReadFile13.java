import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
class ReadFile13
{
    public static void main(String[] args) throws IOException
    {
        String fileName = "demo.txt";
        
        int ch;
  
        
        FileReader fr=null;
        try
        {
            fr = new FileReader(fileName);
        }
        catch (FileNotFoundException fe)
        {
            System.out.println("File not found");
        }
  
        
        while ((ch=fr.read())!=-1)
            System.out.print((char)ch);
  
        // close the file
        fr.close();
    }
}
