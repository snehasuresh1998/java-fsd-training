import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;
class ReadFile14
{
    public static void main(String[] args) throws IOException
    {
        
        File file = new File("demo.txt");
        FileReader input = null;
        int
        
        try
        {
            input =  new FileReader(file);
        }
        catch (FileNotFoundException fe)
        {
            System.out.println("File not found");
        }
  
        
        while ((ch=input.read())!=-1)
            System.out.print((char)ch);
        input.close();
    }
}
