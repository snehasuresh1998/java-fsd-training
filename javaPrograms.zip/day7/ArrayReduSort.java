import java.io.*;
import java.util.*;

class BubbleSort
{
	void bubbleSort(int arr[])
	{ //
		int n = arr.length; 
		for (int i = 0; i < n-1; i++) 
			for (int j = 0; j < n-i-1; j++)
			{
				if (arr[j] > arr[j+1])
				{
					
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
				
			}
	}
	void printArray(int arr[])
	{
		int n = arr.length;
		System.out.println("The sorted elements :");
		for (int i=0; i<n; i++)
			System.out.print(arr[i] + " ");
		System.out.println();
	}
}

class ArrayReduSort
{    
	public static void main(String[] args)
	{
	int n ,count=0;
	
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter the size of the array :");
	n=sc.nextInt();
	int[] ar= new int[n];
	int[] ar1= new int[n];
	
	System.out.println("Enter the array elements :");
	for(int i=0;i<n;i++)
	{
     ar[i]=sc.nextInt();
	}
	System.out.println("Enter the second elements :");
	for(int i=0;i<n;i++)
	{
     ar1[i]=sc.nextInt();
	}
	int[] redun= new int[n];
  
	for (int i = 0; i < n; i++)
	 {
            for(int j=0;j<n;j++)
            {

            
                if (ar[i] == ar1[j]) 
                {
 
                 
                    redun[i]=ar[i];
                   
                }
            }
        }

	System.out.println(redun.length);
	System.out.println("The similar elements array :");
     for(int i=0;i<n;i++)
	{
     System.out.println(redun[i]);
	}
     BubbleSort obj=new  BubbleSort();
    obj.bubbleSort(redun);
    obj.printArray(redun);
	}
	
}
