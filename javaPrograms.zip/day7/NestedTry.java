
class NestedTry {
  
    
    public static void main(String args[])
    { 
        int number;
        
        try {
  
            
              String ptr=null;
              if (ptr.equals("gfg"))
                 System.out.println("Same");
           
            try {
  
                
                number=Integer.parseInt("null");
            }
            catch (NumberFormatException e2) {
                System.out.println(e2);
            }
        }
        catch (NullPointerException e1) {
            System.out.println("NumberFormatException ");
            System.out.println("NullPointerException");
        }
    }
    
}