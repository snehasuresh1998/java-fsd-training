import java.io.FileReader;
import java.io.IOException;
 
public class FileReaderExample 
{
    public static void main(String[] args) throws IOException
    {
        String fileName = "demo.txt";
         
        FileReader fileReader = new FileReader(fileName);
         
        try {
            char [] a = new char[2048];
            fileReader.read(a);   
               
            for(char c : a) {
                System.out.print(c);   
            }
        } finally {
            fileReader.close();
        }
    }
}