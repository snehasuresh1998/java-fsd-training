import java.io.*;
public class Example21
{
public static void append(String fileName,
String string)
{
try {

BufferedWriter out1 = new BufferedWriter(
new FileWriter(fileName, true));
out1.write(string);
out1.close();
}
catch (IOException e) {
System.out.println("occurance of exception" + e);
}
}
public static void main(String[] args)
throws Exception
{

String fileName = "Shobha.txt";
try {
BufferedWriter out1 = new BufferedWriter(
new FileWriter(fileName));
out1.write("Learning appending\n");
out1.close();
}
catch (IOException e) {
System.out.println("occurance of exception" + e);
}

String string = "Learning is good";
append(fileName, string);

try {
BufferedReader in1 = new BufferedReader(
new FileReader("Shobha.txt"));
String mystr;
while ((mystr = in1.readLine()) != null) {
System.out.println(mystr);
}
}
catch (IOException e) {
System.out.println("Occurance of exception" + e);
}
}
}