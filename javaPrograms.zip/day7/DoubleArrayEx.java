import java.util.*;
import java.util.Collections;

class  DoubleArrayEx
{
	public static void main(String[] args)
	{
		ArrayList<Double> a=new ArrayList<Double>();
		System.out.println("Enter your limit :");
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
        System.out.println("Enter the elements :");
		for (int i = 0; i < n; i++)
		{  
		   Double  e= sc.nextDouble();
           a.add(e);
		}
		System.out.println(a);
		Double sum=0.0;
		Iterator itr= a.iterator();
		while(itr.hasNext())
		{   
			Double a1=(Double)itr.next();
		    sum=sum+a1;
			
		}
		System.out.println("Sum of the elements in the list is : " + sum);
		
		System.out.println(" The elements in descending order : ");
		Collections.sort(a, Collections.reverseOrder());
		System.out.println(a);
	}
}