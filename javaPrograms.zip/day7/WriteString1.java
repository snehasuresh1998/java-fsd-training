import java.io.IOException;
import java.io.FileWriter;

class WriteString1
{
    public static void main(String[] args) throws IOException
    {
        
        
        String str =" hello welcome";
        
       
        FileWriter fw=new FileWriter("output.txt");
  
        
        
            fw.write(str);
  
  
        System.out.println("Writing successful");
       
         
        fw.close();
    }
}