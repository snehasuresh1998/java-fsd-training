import java.util.*;
import java.util.Collections;
class DoubleString
{
	public static void main(String[] args)
	{
		ArrayList<String> a=new ArrayList<String>();
		ArrayList<String> b=new ArrayList<String>();
		ArrayList<String> s=new ArrayList<String>();
		//System.out.println("Enter your limit :");
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
        System.out.println("Enter the First names :");
		for (int i = 0; i < n; i++)
		{  
		   String e= sc.next();
           a.add(e);
		}
		System.out.println("Enter the Second names :");
		for (int i = 0; i < n; i++)
		{  
		   String e1= sc.next();
           b.add(e1);
		}
		Iterator itr= a.iterator();
		Iterator itr1= b.iterator();
		while(itr.hasNext() && itr1.hasNext())
		{   
			String s1=(String) itr.next();
			String s2=(String) itr1.next();

			s.add(s1.concat(" "+s2));
		}

		System.out.println(s);	
		
	}
}