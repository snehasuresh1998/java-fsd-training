import java.util.*;
import java.util.Collections;
class DoubleString1
{
	public static void main(String[] args)
	{
		ArrayList<String> a=new ArrayList<String>();
		ArrayList<String> b=new ArrayList<String>();
		ArrayList<String> s=new ArrayList<String>();
        a.add("sneha");
        a.add("sandra");
        a.add("sandhya");
        System.out.println("Enter the Second names :");

           b.add("suresh");
           b.add("suresh");
           b.add("suresh");
		
		Iterator itr= a.iterator();
		Iterator itr1= b.iterator();
		while(itr.hasNext() && itr1.hasNext())
		{   
			String s1=(String) itr.next();
			String s2=(String) itr1.next();

			s.add(s1.concat(" "+s2));
		}

		System.out.println(s);	
		
	}
}