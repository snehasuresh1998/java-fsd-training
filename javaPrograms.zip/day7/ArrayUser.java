import java.util.*;
import java.util.Collections;
class Book
{  
    
  String name , author;  
  int yop, copy;  
  Book(String name,String author,int yop,int copy)
 {  
   
   this.name=name;
   this.author=author;  
   this.yop=yop;
   this.copy=copy; 
  }  
}

 class ArrayUser
 {  
	 public static void main(String[] args)
	 {  
		  
		  Book s1=new Book("aaa","aba",2017,2450); 
		  Book s2=new Book("axxx","absgaha",2010,240);  
		   
		  
		  ArrayList<Book> al=new ArrayList<Book>(); 
		  ArrayList<Book> a2=new ArrayList<Book>();  
		  al.add(s1); 
		  al.add(s2);    
		  Iterator itr=al.iterator();  
		  while(itr.hasNext())
		  {  
		    Book st=(Book)itr.next();
		  }  
		    
		 

	 }  
 } 