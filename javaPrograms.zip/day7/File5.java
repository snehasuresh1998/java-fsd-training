import java.io.FileWriter;
import java.io.IOException;
class File5
{
    public static void main(String[] args) throws IOException
    {
        
        
        char c='a';
  
       
        FileWriter fw=new FileWriter("output.txt");
  
        
        
            fw.write(c);
  
        System.out.println("Writing successful");
         
        fw.close();
    }
}
