import java.io.FileReader;
import java.io.IOException; 
public class CreateFile1 
{
  public static void main(String[] args) {
 String name = "demo.txt";
FileReader input = new FileReader(name);
