import java.util.*;
import java.lang.*;
class ExceptionClass1
{
 public static void main(String[] args)
 {
 	int number;
 	try
 	{
 		   String ptr=null;
 		   if (ptr.equals("gfg"))
 	           System.out.println("Same");
 	    try
 	       {
 		   number=Integer.parseInt("null");
 	       }
 	       catch(NumberFormatException e1)
 	       {
 		   System.out.println(e1);
 	       }
 	}
 	       
 	catch(NullPointerException e){
 		System.out.println(e);
 	}
   
 	System.out.println(" This is an example for  Exception");
 }
}

