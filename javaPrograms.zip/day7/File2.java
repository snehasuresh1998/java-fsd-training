import java.io.*;  // Import the File class
import java.io.IOException; 
class File2
{
 public static void main(String[] args)
  {
		

	FileInputStream f1=null;
	try
	{
		f1=new FileInputStream("demo.txt");
		int b;
		while((b=f1.read())!= -1)
		{
			System.out.println((char) b);
		}
	}catch(IOException e)
	{
		System.out.println(e);
	}
}
}