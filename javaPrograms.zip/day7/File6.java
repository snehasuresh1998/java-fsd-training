import java.io.IOException;
import java.io.FileWriter;

class File6
{
    public static void main(String[] args) throws IOException
    {
        
        
        char[] c1={'a','b','c'};
        
       
        FileWriter fw=new FileWriter("output.txt");
  
        
        
            fw.write(c1);
  
  
        System.out.println("Writing successful");
        fw.flush();
         
        fw.close();
    }
}
