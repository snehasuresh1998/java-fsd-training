import java.io.FileWriter;   
import java.io.IOException; 
import java.util.*; 
class CharRead
{
  public static void main( String args[])
  {
    BufferedReader br = new Bufferedreader(new InputstreamReader(System.in));
    char c = (char)br.read();   //Reading character
  }
}