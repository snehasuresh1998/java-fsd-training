import java.util.*;
class ArrayList14
{
	public static void main(String[] args)
	{
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<Integer> b=new ArrayList<Integer>();
		a.add(1);
		a.add(2);
		a.add(3);
		System.out.println(a);
		b.add(6);
		b.add(7);
		b.add(8);
		System.out.println(b);
		Iterator itr= a.iterator();
		Iterator itr1= b.iterator();
		while(itr.hasNext()&&itr1.hasNext() )
		{
			System.out.println(int sum=itr.next()+itr1.hasNext());
		}
	}
}
