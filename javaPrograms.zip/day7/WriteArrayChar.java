import java.io.IOException;
import java.io.FileWriter;

class WriteArrayChar
{
    public static void main(String[] args) throws IOException
    {
      char c1='a';
      FileWriter fw=new FileWriter("output.txt");
      fw.write(c1);
      System.out.println("Written successful");
      fw.close();
    }
}
