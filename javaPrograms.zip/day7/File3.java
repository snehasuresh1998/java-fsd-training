import java.io.*;  // Import the File class
import java.io.IOException; 
class File3
{
 public static void main(String[] args)
  {
		

	FileOutputStream f1=null;
	byte b[]={'a','b'};
	try
	{
		f1=new FileOutputStream("a1.txt");
		f1.write(b);
		f1.close();
		System.out.println("successfully written");
	}catch(IOException e)
	{
		System.out.println(e);
	}
}
}