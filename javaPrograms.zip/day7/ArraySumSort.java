import java.io.*;
import java.util.*;
class SelectionSort
{
	void sort(int arr[])
	{  					
		int n1 = arr.length; 

		
		for (int i = 0; i < n1-1; i++) 
		{
			
			int min_idx = i;
			for (int j = i+1; j < n1; j++) 
				{
				if (arr[j] < arr[min_idx])
					min_idx = j;
			}

			
			int temp = arr[min_idx];
			arr[min_idx] = arr[i];
			arr[i] = temp;
		}
	}

	
	void printArray(int arr[])
	{
		int n1 = arr.length;
		System.out.println("The sorted array:");
		for (int i=0; i<n1; ++i)
			System.out.print(arr[i]+" ");
		System.out.println();
	}
}

class ArraySumSort
{    
	public static void main(String[] args)
	{
	int n;
	
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter the size of the array :");
	n=sc.nextInt();
	int[] ar= new int[n];
	int[] ar1= new int[n];
	int[] sum= new int[n];
	System.out.println("Enter the array elements :");
	for(int i=0;i<n;i++)
	{
     ar[i]=sc.nextInt();
	}
	System.out.println("Enter the second elements :");
	for(int i=0;i<n;i++)
	{
     ar1[i]=sc.nextInt();
	}

	for(int i=0;i<n;i++)
	{
     sum[i]=ar[i]+ar1[i];
	}
	System.out.println("The sum array :");
     for(int i=0;i<n;i++)
	{
     System.out.println(sum[i]);
	}
   SelectionSort obj =new SelectionSort();
     obj.sort(sum);

     obj.printArray(sum);
	}
	
}
