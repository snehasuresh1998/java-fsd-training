import java.io.IOException;
import java.io.FileWriter;

class WriteCons
{
    public static void main(String[] args) throws IOException
    {
      String n="output.txt";
      FileWriter fw=new FileWriter(n);
      fw.write("welcome 2022");
      System.out.println("Written successful");
      fw.close();
    }
}
