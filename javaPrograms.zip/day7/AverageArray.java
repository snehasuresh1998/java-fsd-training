import java.util.*;
import java.util.Collections;
class AverageArray
{
	public static void main(String[] args)
	{
		ArrayList<Integer> a=new ArrayList<Integer>();
		a.add(1);
		a.add(2);
		a.add(3);
		int sum=0;
		Iterator itr= a.iterator();
		while(itr.hasNext())
		{   
			int a1=(Integer)itr.next();
		    sum=sum+a1;
			
		}
		System.out.println("Sum of the elements in the list is : " +sum);
		double d=sum/3;
		System.out.println(" The average of the eleents is : " +d);
	}
}