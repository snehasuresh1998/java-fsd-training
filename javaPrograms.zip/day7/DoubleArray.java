import java.util.*;
import java.util.Collections;
class DoubleArray
{
	public static void main(String[] args)
	{
		ArrayList<Integer> a=new ArrayList<Integer>();
		ArrayList<Integer> b=new ArrayList<Integer>();
		ArrayList<Integer> s=new ArrayList<Integer>();
		a.add(1);
		a.add(2);
		a.add(3);
		System.out.println(a);
		b.add(6);
		b.add(7);
		b.add(8);
		System.out.println(b);
		Iterator itr= a.iterator();
		Iterator itr1= b.iterator();
		while(itr.hasNext()&&itr1.hasNext())
		{   
			int a1=(Integer)itr.next();
			int a2= (Integer) itr1.next();
			int sum=a1+a2;
			s.add(sum);
			System.out.println(sum);
		}
		Collections.sort(s, Collections.reverseOrder());
		System.out.println(s);
	}
}
