import java.io.FileReader;

class Main4 {
  public static void main(String[] args) {

    
    char[] array = new char[100];

    try {
     
      FileReader input = new FileReader("demo.txt");

   
      //input.read(array);
      //System.out.println(array);
      input.read(array,1,4);
      System.out.println(array);
      //input.skip(2);
      //System.out.println(array);
      System.out.println("Data in the file: ");
      

      
      input.close();
    }

    catch(Exception e) {
      System.out.println(e);
    }
  }
}
