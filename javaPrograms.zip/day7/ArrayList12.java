import java.util.*;
class ArrayList12
{
	public static void main(String[] args)
	{
		ArrayList<String> s=new ArrayList<String>();
		s.add("sanu");
		s.add("anu");
		s.add("vinu");
		System.out.println(s);
		Iterator itr= s.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
	}
}