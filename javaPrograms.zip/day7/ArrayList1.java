import java.util.*;
class ArrayList1
{
	public static void main(String[] args)
	{
		ArrayList<String> s=new ArrayList<String>();
		s.add("sanu");
		s.add("anu");
		s.add("vinu");
		System.out.println(s);
	}
}